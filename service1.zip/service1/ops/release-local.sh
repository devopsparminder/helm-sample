export ROOT="/home/parsadmin@sys.dom/test/nodejs-sample/service1/deploy"
export RELEASE=devops
export NAMESPACE=default
export CLUSTER_NAME=az-devops-test

export TERM=xterm-256color

echo "$(tput setaf 2)######################################################################$(tput sgr0)"
echo "Create kind $CLUSTER_NAME cluster..."
kind create cluster --name $CLUSTER_NAME --image artifacts.cf.saxo/docker/kindest/node:v1.19.11@sha256:07db187ae84b4b7de440a73886f008cf903fcf5764ba8106a9fd5243d6f32729 
echo "$(tput setaf 2)######################################################################$(tput sgr0)"
echo ""
echo ""
echo "$(tput setaf 2)######################################################################$(tput sgr0)"
echo "kubectl cluster-info --context kind-$CLUSTER_NAME"
docker container ls
echo ""
kubectl cluster-info --context kind-$CLUSTER_NAME
echo ""
echo ""
docker container ls
echo "$(tput setaf 2)######################################################################$(tput sgr0)"
echo "helm repo update"
helm repo update
echo "$(tput setaf 2)######################################################################$(tput sgr0)"
echo ""
echo ""
echo "$(tput setaf 2)######################################################################$(tput sgr0)"
echo "helm install devops helm/devops"
helm install devops helm/devops
echo "$(tput setaf 2)######################################################################$(tput sgr0)"
echo ""
echo ""         
echo "$(tput setaf 2)######################################################################$(tput sgr0)" 
echo "kubectl get nodes -o wide"
kubectl get nodes -o wide
echo ""
echo ""        
echo "$(tput setaf 2)######################################################################$(tput sgr0)"              
echo "kubectl get services"
kubectl get services
echo ""
echo ""
echo "$(tput setaf 2)######################################################################$(tput sgr0)" 
echo "kubectl get deployments"
kubectl get deployments
echo "$(tput setaf 2)######################################################################$(tput sgr0)"
echo ""
echo ""
echo "kubectl get pods"
kubectl get pods
echo "$(tput setaf 2)######################################################################$(tput sgr0)"
echo ""
echo ""
#"${{ parameters.releaseLocalScriptPath }}" "$(Build.BuildNumber)" "${{ parameters.dockerSdkBaseImage }}" "${{ parameters.dockerRuntimeBaseImage }}"
rc=$?
echo "$(tput setaf 2)######################################################################$(tput sgr0)"
echo "$(tput setaf 2)##$(tput sgr0) Trace"
#kubectl --context "kind-${BUILD_BUILDID}" get all,ingress,certs,secrets,events -A -o wide
echo "$(tput setaf 2)######################################################################$(tput sgr0)"
exit $rc